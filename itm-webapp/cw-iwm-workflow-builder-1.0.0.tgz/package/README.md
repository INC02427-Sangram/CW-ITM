WorkflowManager is the main component were the applciation will starts.
we have some props like

1.endPoint="" // we need to pass while consuming the app
2.theme = "greenTheme" for color
3.isThemeChangeIcon={true} // to show the theme icon in the component
4.token="" // pass token from consuming host app for azure. For BTP do not pass the token
5.# For Azure environment
VITE_USER_NODE_ENV='azure'
# For BTP environment
VITE_USER_NODE_ENV='btp'
