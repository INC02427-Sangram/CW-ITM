﻿# Cherrybot — Bot Configs UI

A focused, production-ready frontend for managing Cherrybot configuration, monitoring, and chat interfaces.

Built with Vite, React, and TypeScript. The UI provides tools to upload training data, configure bot behavior, view monitoring dashboards, and interact with chat variants (compact and full-screen).

Key technologies
- Vite + TypeScript
- React (functional components + hooks)
- Redux for global state where applicable
- React Context for local cross-cutting state
- CSS modules / design system components (project-specific)

Quick start
-----------
Prerequisites:
- Node.js 16+ (use the version compatible with your CI / infra)
- npm or yarn

Install dependencies:

```bash
npm install
```

Run development server:

```bash
npm run dev
```

Build for production:

```bash
npm run build
```

Preview production build locally:

```bash
npm run preview
```

Useful scripts (check `package.json` for exact names):
- `dev` — start Vite dev server
- `build` — produce a production bundle
- `preview` — preview the built output
- `lint` / `format` — linting and formatting tasks

Project layout (high level)
---------------------------
- `src/`
  - `auth/` — authentication helpers and callbacks
  - `pages/` — top-level page entries (Login, Home, etc.)
  - `features/` — grouped feature areas (chat, monitoring, config manager)
  - `container/` — app container components and wiring
  - `services/` — HTTP clients and API integrations
  - `utils/` — utility helpers and shared UI helpers
  - `contexts/` — React Context providers
  - `redux/` and `store/` — reducers and store setup
  - `assets/` — static assets (svgs, images)
  - `config/` — runtime constants and URLs (moved from legacy `configs/`)

Configuration
-------------
- Runtime API endpoints, client IDs and constants live under `src/config/`.
- Update OAuth and identity provider details in `src/auth/` and the Login page if using SSO.
- Prefer environment-specific configuration via your host/CI; the app reads values from the `src/config/*` files by default.

Clean-up & migration notes
--------------------------
This repo recently adopted a feature-oriented structure (`src/features`, `src/pages`, `src/services`, `src/utils`). If you see old import paths referencing `src/components/` or `src/configs/`, they were migrated to the new layout — expect a smaller number of residual path changes during development.

Best practices
--------------
- Use `src/services/` for API wrappers and centralized HTTP logic.
- Keep presentation components in `features/*` or `pages/*` and business logic in hooks/services.
- Add unit tests for critical logic (API wrappers, reducers, helpers).
- Use path aliases (`tsconfig.json`) sparingly to keep imports readable.

Contributing
------------
- Fork the repository and open a pull request with a clear description.
- Keep changes small and focused. Run `npm run build` and the linter before opening PRs.

Extras & next steps I can help with
----------------------------------
- Add a minimal `LICENSE` (MIT/Apache) if you want to open-source this project.
- Add CI (GitHub Actions) to run lint/build on PRs.
- Add an example `.env.example` and docs for configuring OAuth providers.

If you want any of the above automated, tell me which and I will implement it.

---
_Generated/updated on December 26, 2025_
