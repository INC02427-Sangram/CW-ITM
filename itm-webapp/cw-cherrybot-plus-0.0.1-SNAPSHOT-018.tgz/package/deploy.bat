@echo off
setlocal

echo ===== Step 1: Building the app =====
call npm run build
if errorlevel 1 (
  echo ERROR: npm run build failed.
  pause
  exit /b 1
)

echo ===== Step 2: Adding Staticfile to dist =====
(
  echo pushstate: enabled
) > dist\Staticfile
if errorlevel 1 (
  echo ERROR: Failed to create Staticfile.
  pause
  exit /b 1
)

echo ===== Step 3: Logging in to Cloud Foundry =====
cf8 login -a https://api.cf.eu10-004.hana.ondemand.com -u "nitish.bharadwaj@incture.com" -p "Nitish@123"
if errorlevel 1 (
  echo ERROR: CF login failed.
  pause
  exit /b 1
)

echo ===== Step 4: Deploying app with cf push =====
cf8 push
if errorlevel 1 (
  echo ERROR: Deployment failed.
  pause
  exit /b 1
)

echo Deployment completed successfully!
pause
endlocal
