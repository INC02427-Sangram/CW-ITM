//For Application Build

// import { defineConfig } from "vite";
// import react from "@vitejs/plugin-react-swc";

// // https://vite.dev/config/
// export default defineConfig({
//   plugins: [react()],
//   server: {
//     port: 3000,
//   },
// });

//For Artifact Build

/// <reference types="vite/client" />

import { defineConfig } from 'vite';
import { extname, relative, resolve } from 'path';
import { fileURLToPath } from 'node:url';
import { glob } from 'glob';
import pkg from './package.json';

const entries = Object.fromEntries(
  glob
    .sync('src/**/*.{ts,tsx}', {
      ignore: ['**/*.d.ts', '**/*.test.ts', '**/*.test.tsx']
    })
    .map(file => [
      relative('src', file.slice(0, file.length - extname(file).length)),
      fileURLToPath(new URL(file, import.meta.url))
    ])
);

export default defineConfig(() => {

  return {
    build: {
      lib: {
        entry: resolve(__dirname, 'src/index.ts'),
        formats: ['es'] as ('es' | 'cjs' | 'umd' | 'iife')[]
      },
      rollupOptions: (() => {
        // Build a set of dependency names from package.json
        const anyPkg = pkg as any;
        const deps = new Set<string>([
          ...Object.keys(pkg.dependencies || {}),
          ...(anyPkg.peerDependencies ? Object.keys(anyPkg.peerDependencies) : []),
        ]);

        // helper to treat package imports and subpaths as external
        const isExternal = (id: string) => {
          if (!id) return false;
          // always externalize virtual/node: ids
          if (id.startsWith('node:')) return true;
          for (const dep of deps) {
            if (id === dep || id.startsWith(dep + '/')) return true;
          }
          // keep common runtime helpers external
          if (id === 'react/jsx-runtime') return true;
          return false;
        };

        return {
          external: isExternal,
          input: entries,
          output: {
            assetFileNames: 'assets/[name][extname]',
            entryFileNames: '[name].js'
          }
        };
      })(),
    }
  };
});
